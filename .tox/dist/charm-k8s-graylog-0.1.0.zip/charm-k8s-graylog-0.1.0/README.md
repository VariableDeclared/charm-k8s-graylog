# Graylog Charm for Kubernetes

CI Bages
--------

TODO

Overview
--------

Deploy and configure Graylog on any Kubernetes quickly and easily.

Usage
------

`juju deploy <charmstore url>`

To develop this charm
